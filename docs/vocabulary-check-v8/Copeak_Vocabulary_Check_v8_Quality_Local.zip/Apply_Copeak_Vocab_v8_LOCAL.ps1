﻿# Copeak Vocabulary Check v8 — LOCAL-ONLY SAFE UPDATE.
# Affects only vocabulary-check.html/.js/.css and new data/v8-diagnostic-800.json.
# Preserves 5,000-item v7 bank, progress history, Copeak main app, audio and Classroom.
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$projectRoot = (Get-Location).Path
$packageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
function Require([string]$path) {
  if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "SAFETY STOP: Missing $path" }
}
function NormalizedSha([string]$path) {
  $text = [System.IO.File]::ReadAllText($path).Replace("`r`n", "`n")
  $sha = [System.Security.Cryptography.SHA256]::Create()
  try {
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($text)
    return (-join ($sha.ComputeHash($bytes) | ForEach-Object { $_.ToString('x2') })).ToLowerInvariant()
  } finally { $sha.Dispose() }
}
function RawSha([string]$path) {
  return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
}
$expectV7Data = '87a02a9a92e03a749cb0c33c54f3247d8ed99b0a43db178116e5a279c261bcd7'
$expectV7JS   = '8ddb8df9a19be599853e7a6ed0c586480fe80052c8f16cc61562e6448fb68026'
$knownHTML    = @('5a625363638f7da21069e1841b37283f1070233a662dd49c6eb8adce1fdaf7de','bcd1f35cd4695706b3cc34bd27775761b08c37d526515eb05e1c2a751748185d')
$knownCSS     = @('d37114cf938c187f02f2464ffb15f34335760b9b24532ffc0323ee2aec91abec')
$expectedPayload = @{
  'vocabulary-check.js'            = '65a0033cd7018159a342f5648f80870b55ba8e3cc85d76d9ebff1242504c917c'
  'vocabulary-check.html'          = '4de280caaf2c8bf77886d5f5a6e659c75b8e50d9cf1ce4b18949978fa0585ce8'
  'vocabulary-check.css'           = '9ee149c1e3a81208f9a25e637c1238b512170b3082018a931cf1c189ce85dd14'
  'data/v8-diagnostic-800.json'    = 'ba3d0869b85ca3db1d5b12e990a8ca938fe7ee98f332f00753917fbe6a3cebe5'
}
$originalBank = Join-Path $projectRoot 'data/chunks-v7.json'
Require (Join-Path $projectRoot 'index.html')
Require $originalBank
if ((RawSha $originalBank) -ne $expectV7Data) { throw 'SAFETY STOP: 5,000-item bank differs from verified v7.' }
foreach ($rel in $expectedPayload.Keys) { Require (Join-Path $packageRoot $rel) }
foreach ($rel in @('vocabulary-check.html','vocabulary-check.js','vocabulary-check.css')) { Require (Join-Path $projectRoot $rel) }
$targetDiag = Join-Path $projectRoot 'data/v8-diagnostic-800.json'
$already = ((NormalizedSha (Join-Path $projectRoot 'vocabulary-check.js')) -eq $expectedPayload['vocabulary-check.js']) -and
  (Test-Path -LiteralPath $targetDiag -PathType Leaf) -and
  ((NormalizedSha $targetDiag) -eq $expectedPayload['data/v8-diagnostic-800.json']) -and
  ((NormalizedSha (Join-Path $projectRoot 'vocabulary-check.html')) -eq $expectedPayload['vocabulary-check.html']) -and
  ((NormalizedSha (Join-Path $projectRoot 'vocabulary-check.css')) -eq $expectedPayload['vocabulary-check.css'])
if ($already) { Write-Host 'ALREADY INSTALLED: Vocabulary Check v8 (local).' -ForegroundColor Cyan; exit 0 }
if (Test-Path -LiteralPath $targetDiag) { throw 'SAFETY STOP: A pre-existing v8 diagnostic bank was found; not overwriting.' }
if ((NormalizedSha (Join-Path $projectRoot 'vocabulary-check.js')) -ne $expectV7JS) {
  throw 'SAFETY STOP: Active JS is not verified v7. Nothing was changed.'
}
if ($knownHTML -notcontains (NormalizedSha (Join-Path $projectRoot 'vocabulary-check.html'))) {
  throw 'SAFETY STOP: Local HTML has custom changes. Inspect and merge manually; nothing changed.'
}
if ($knownCSS -notcontains (NormalizedSha (Join-Path $projectRoot 'vocabulary-check.css'))) {
  throw 'SAFETY STOP: Local CSS has custom changes. Inspect and merge manually; nothing changed.'
}
foreach ($rel in $expectedPayload.Keys) {
  if ((NormalizedSha (Join-Path $packageRoot $rel)) -ne $expectedPayload[$rel]) {
    throw "SAFETY STOP: Package checksum mismatch in $rel"
  }
}
$node = Get-Command node -ErrorAction SilentlyContinue
if (-not $node) { throw 'SAFETY STOP: Node.js is required. No files changed.' }
& $node.Source '--check' (Join-Path $packageRoot 'vocabulary-check.js')
if ($LASTEXITCODE -ne 0) { throw 'SAFETY STOP: v8 JavaScript syntax check failed.' }
& $node.Source (Join-Path $packageRoot 'tests/v8_quality.test.mjs')
if ($LASTEXITCODE -ne 0) { throw 'SAFETY STOP: v8 data/behavior checks failed.' }
$backupDir = Join-Path $projectRoot ('_copeak_vocab_backups/v8-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
foreach ($rel in @('vocabulary-check.html','vocabulary-check.js','vocabulary-check.css')) {
  Copy-Item -LiteralPath (Join-Path $projectRoot $rel) -Destination (Join-Path $backupDir $rel) -Force
}
try {
  foreach ($rel in $expectedPayload.Keys) {
    $dest = Join-Path $projectRoot $rel
    $parent = Split-Path -Parent $dest
    if (-not (Test-Path $parent)) { New-Item -ItemType Directory -Force -Path $parent | Out-Null }
    Copy-Item -LiteralPath (Join-Path $packageRoot $rel) -Destination $dest -Force
  }
  foreach ($rel in $expectedPayload.Keys) {
    if ((NormalizedSha (Join-Path $projectRoot $rel)) -ne $expectedPayload[$rel]) {
      throw "SAFETY STOP: Post-install mismatch: $rel"
    }
  }
  if ((RawSha $originalBank) -ne $expectV7Data) { throw 'SAFETY STOP: Original v7 bank changed.' }
} catch {
  foreach ($rel in @('vocabulary-check.html','vocabulary-check.js','vocabulary-check.css')) {
    Copy-Item -LiteralPath (Join-Path $backupDir $rel) -Destination (Join-Path $projectRoot $rel) -Force
  }
  if (Test-Path -LiteralPath $targetDiag) { Remove-Item -LiteralPath $targetDiag -Force }
  throw
}
Write-Host 'SUCCESS: Copeak Vocabulary Check v8 installed LOCALLY.' -ForegroundColor Green
Write-Host 'LEARNING: Original 5000 entries untouched.'
Write-Host 'DIAGNOSTIC: 800 draft review candidates (100 per provisional level).'
Write-Host 'ENGINE: Broad probes, family diversity, fixed bilingual distractors, evidence, review guidance, voluntary anonymous CSV.'
Write-Host 'ACCURACY: Teacher review and pilot calibration still REQUIRED. Eiken and grade mappings are NOT validated.'
Write-Host 'HISTORY: Preserved; audio and Classroom untouched.'
Write-Host "BACKUP: $backupDir"
Write-Host 'GITHUB: No push. VERCEL: No deployment.'
Write-Host 'NEXT: Live Server > vocabulary-check.html > Ctrl + Shift + R.'

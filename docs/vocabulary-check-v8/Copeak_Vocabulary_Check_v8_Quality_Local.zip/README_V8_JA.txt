Copeak Vocabulary Check v8（診断精度向上／ローカル専用）

【導入対象】v7の5,000件をインストール済みの copeak プロジェクト。
【変更対象】vocabulary-check.html / vocabulary-check.js / vocabulary-check.css / data/v8-diagnostic-800.json のみ。
【完全保持】data/chunks-v7.json（5,000件）、学習履歴 localStorage、音声、Copeak Classroom、他のプロジェクト。
【GitHub・Vercel】自動Push／自動デプロイなし。

導入：VS CodeでCopeakプロジェクトを開き、ZIPをDownloadsに保存・展開、PowerShellで Apply_Copeak_Vocab_v8_LOCAL.ps1 を実行。
安全検査が変更を検出した場合には中止し、既存環境を強制的に書き換えません。
導入後は Live Server で vocabulary-check.html を開き、Ctrl+Shift+R で再読み込み。

診断用800件は教員査読前の候補（各レベル100件）。5,000件のうち代表的な表現を機械的に抽出したものです。
人手で校正された問題、英検・CEFRの正式対応、実測難易度、統計的信頼区間を意味しません。

追加機能：同一家族の重複回避、最初の8問で広くレベル探索、残りの適応出題、根拠表示、弱点分析、希望時のみ匿名試行回答CSV出力。
旧履歴形式と同じ localStorage キーを保持し、既存履歴も表示します。

検証方法：node tests/v8_quality.test.mjs
監査ファイル：ALL_5000_AUDIT.csv / DIAGNOSTIC_800_TEACHER_REVIEW.csv / AUDIT_SUMMARY.json / v8_quality_report.html

次の品質ゲート：教師の用例・訳・選択肢の査読→生徒によるパイロット→項目統計／レベル妥当性の推定。
